import java.lang.*;

class Contador {
  long i;
  public long get() {
    return i;
  }
  public void inc() {
    i++;
  }
}

class Incrementer implements Runnable {
  Contador c;
  Incrementer(Contador c1) {
    c = c1;
  }
  public void run() {
    for (long i = 0; i < 10000000; i++)
      c.inc();
  }
}

class M {
  public static void main(String[] args) {
  try {
    Contador c;
    Thread t1, t2;

    c = new Contador();
    t1 = new Thread(new Incrementer(c));
    t2 = new Thread(new Incrementer(c));
    t1.start();
    t2.start();
    t1.join();
    t2.join();
    System.out.println(c.get());

  } catch (InterruptedException e) {}
  }
}


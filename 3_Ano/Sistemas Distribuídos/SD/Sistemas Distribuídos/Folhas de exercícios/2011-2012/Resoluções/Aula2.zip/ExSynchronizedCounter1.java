
class Contador {
  long i;
  public long get() {
    return i;
  }
  public synchronized void inc() {
    i++;
  }
}

class Incrementer implements Runnable {
  Contador c;
  Incrementer(Contador c1) {
    c = c1;
  }
  public void run() {
    for (long i = 0; i < 10000000; i++)
      c.inc();
  }
}

class ExSynchronizedCounter {
	public static void main(String[] args) {
	try {
		Contador c;
		Incrementer worker;
		Thread t[] = new Thread[10];

		c = new Contador();
		worker = new Incrementer(c);

		// Several threads will animate the same worker
		// this is fine "run()" since vars are on stack
		// and constructor is only called once
		for (int i=0; i<10; i++)
			t[i]= new Thread(worker);

		for (int i=0; i<10; i++)
			t[i].start();

		for (int i=0; i<10; i++)
			t[i].join();

		System.out.println(c.get());

	} catch (InterruptedException e) {}
	}
}


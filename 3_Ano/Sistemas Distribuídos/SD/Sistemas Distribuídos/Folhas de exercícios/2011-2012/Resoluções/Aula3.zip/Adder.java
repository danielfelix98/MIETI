import java.util.Random;

class Adder implements Runnable {
  Banco b;
  public Adder(Banco b) {
    this.b = b;
  }
  public void run() {
	Random rand = new Random();
	int ncontas=b.getNcontas();
	int sum, i, tries, lsum=0;
   for(tries=0; tries<1000000; tries++)
	{ 
		sum=0;
		for (i=0; i<ncontas; i++)
		{
			sum+=b.consulta(i);
		}
		if (lsum!=sum) System.out.println("Total "+sum);
		lsum=sum;
	}
   }
}
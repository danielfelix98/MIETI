
/**
 * Write a description of class Banco here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
import java.util.*;

public class Banco{
    
    private HashMap<Integer, Conta> contas;
    private int ncontas;
    
    public Banco(){
        contas = new HashMap<Integer, Conta>();
        ncontas = 0;
    }
    
    public Banco(int n){
        contas = new HashMap<Integer, Conta>();
        ncontas = n;
    }
    
    public Banco(HashMap<Integer, Conta> c, int i){
        contas = new HashMap<Integer, Conta>();
        contas = c;
        ncontas = i;
    }
    
    public Banco(Banco b){
        contas = b.getContas();
        ncontas = b.getNcontas();
    }
    
    public HashMap<Integer, Conta> getContas(){
        return contas;
    }

    public int getNcontas(){
        return ncontas;
    }
    
    public synchronized int consulta(int s){
        return contas.get(s).getSaldo();
    }
    
    public synchronized void credita(int s, int d){
        contas.get(s).somaSaldo(d);
    }
    
    public synchronized void debita(int s, int d){
        contas.get(s).somaSaldo(-d);
    }
}

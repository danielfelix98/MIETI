
/**
 * Write a description of class COntas here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Conta{
    
    private int nib;
    private int saldo;
    
    public Conta(){
        nib = 0;
        saldo = 0;
    }
    
    public Conta(int n, int s){
        nib = n;
        saldo = s;
    }
    
    public Conta(Conta c){
        nib = c.getNib();
        saldo = c.getSaldo();
    }
    
    public int getNib(){
        return nib;
    }
    
    public int getSaldo(){
        return saldo;
    }
    
    public void setNib(int s){
        nib = s;
    }
    
    public void setSaldo(int d){
        saldo = d;
    }
    
    public void somaSaldo(int d){
        saldo = saldo + d;
    }
    
    public Conta clone(){
        return new Conta(this);
    }

}

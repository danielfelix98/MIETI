import java.util.HashMap;

class  ExBancoTransf3 {
	public static void main(String[] args) {
		int N = 10; // Number of accounts
		Conta c1 = new Conta(1, 0);
		Conta c2 = new Conta(2, 0);
		Conta c3 = new Conta(3, 0);
		Conta c4 = new Conta(4, 0);
		Conta c5 = new Conta(5, 0);
		Conta c6 = new Conta(6, 0);
		Conta c7 = new Conta(7, 0);
		Conta c8 = new Conta(8, 0);
		Conta c9 = new Conta(9, 0);
		Conta c10 = new Conta(10, 0);
		HashMap<Integer, Conta> cenz = new HashMap<Integer, Conta>();
		cenz.put(c1.getNib(), c1);
		cenz.put(c2.getNib(), c2);
		cenz.put(c3.getNib(), c3);
		cenz.put(c4.getNib(), c4);
		cenz.put(c5.getNib(), c5);
		cenz.put(c6.getNib(), c6);
		cenz.put(c7.getNib(), c7);
		cenz.put(c8.getNib(), c8);
		cenz.put(c9.getNib(), c9);
		cenz.put(c10.getNib(), c10);
		Banco b = new Banco(cenz,N);
		Mover m = new Mover(b);
		Adder c = new Adder(b);

		new Thread(m).start();
		new Thread(c).start();
	}
}
import java.util.Random;

class Bank{
  int slots;
  int[] av;

  public Bank(int n) 
	{ 
		int j;
		slots = n; 
		av=new int[slots];
		for(j=0; j<slots; j++)
		{
			av[j]=0;
		}
	}


  public synchronized void put(int i,int a) {
		av[i]+=a;
		notifyAll();
  }

  public synchronized void take(int i,int a) {
		while ( av[i]-a < 0)
		{
			try
			{
				wait();
			}
			catch (InterruptedException e) {}
		}
		av[i]-=a;
  }

	public synchronized int query(int i)
	{
		return av[i];
	}

	public int slots() { return slots; }

}

class Mover implements Runnable {
  Bank b;
  public Mover(Bank b) {
    this.b = b;
  }
  public void run() {
	Random rand = new Random();
	int slots=b.slots();
	int f;
	int t, tries;
   for(tries=0; tries<1000000; tries++)
	{ 
		f=rand.nextInt(slots); // get one
		while((t=rand.nextInt(slots))==f); // get a distinct other
		synchronized (b) { // Comment this out
			b.take(f,10);
			b.put(t,10);
		}					 	// Comment this out
//		System.out.println("Moved");
	}
   }
}

class FMI implements Runnable {
  Bank b;
  public FMI(Bank b) {
    this.b = b;
  }
  public void run() {
	Random rand = new Random();
	int slots=b.slots();
	int f;
	int tries;
   for(tries=0; tries<1000000; tries++)
	{ 
		f=rand.nextInt(slots); // get one
		b.put(f,10);
	}
	}
}



class  ExBankTransfCV1 {
	public static void main(String[] args) {
		int N = 10; // Number of accounts
		Bank b = new Bank(N);
		Mover m = new Mover(b);
		FMI founds = new FMI(b);

		new Thread(m).start();
		new Thread(founds).start();
	}
}


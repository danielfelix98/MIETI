
import java.util.Random;
import java.util.HashMap;

class Mover implements Runnable {
  Banco b;
  public Mover(Banco b) {
    this.b = b;
  }
  public void run() {
	Random rand = new Random();
	int ncontas=b.getNcontas();
	int f;
	int t; 
	int tries;
   for(tries=0; tries<1000000; tries++)
	{ 
		f=rand.nextInt(ncontas)+1; // get one
		System.out.println(f);
		while((t=rand.nextInt(ncontas)+1)==f); // get a distinct other
		b.debita((Integer)f,10);
		b.credita((Integer)t,10);
	}
   }
}




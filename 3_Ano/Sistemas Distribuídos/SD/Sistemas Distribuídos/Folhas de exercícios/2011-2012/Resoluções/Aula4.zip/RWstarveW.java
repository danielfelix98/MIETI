import java.util.Random;
import java.util.concurrent.locks.ReentrantLock;
import java.util.concurrent.locks.Condition;

class RWreg {
	int reg = 0;
	int readers = 0;
	int writers = 0;
	final ReentrantLock l = new ReentrantLock();
	final Condition OKread = l.newCondition();
	final Condition OKwrite = l.newCondition();

	public void rlock() throws InterruptedException {
		l.lock();
			while (writers != 0) 
				OKread.await();
			readers++;
			OKread.signalAll();
		l.unlock();
	}

	public void runlock() throws InterruptedException {
		l.lock();
			readers--;
			if (readers == 0) 
				OKwrite.signalAll();
		l.unlock();
	}

	public void wlock() throws InterruptedException {
		l.lock();
			while (readers + writers != 0)
				OKwrite.await();
			writers++;
		l.unlock();
	}

	public void wunlock() throws InterruptedException {
		l.lock();
			writers--;
			OKwrite.signalAll(); // A single signal could be enough
			OKread.signalAll();
		l.unlock();
	}

	public int r() throws InterruptedException {
		int lv;
		rlock();
			lv=reg;
		runlock();
		return lv;
	}

	public int w(int v) throws InterruptedException {
		wlock();
			reg=v;
		wunlock();
		return v;
	}

}

class Writer implements Runnable {
  RWreg rw;
  public Writer(RWreg rw) {
    this.rw = rw;
  }
  public void run() {
	Random rand = new Random();
	int v;
    try {
    while(true) { 
		v=rand.nextInt(500);
      Thread.sleep(v);
      System.out.print("Wrote value ");
      System.out.println(rw.w(v));
    }
   } catch (InterruptedException e) {
     System.out.println("Interrupted");
   }
  }
}

class Reader implements Runnable {
  RWreg rw;
  public Reader(RWreg rw) {
    this.rw = rw;
  }
  public void run() {
	Random rand = new Random();
    try {
    while(true) { 
      Thread.sleep(rand.nextInt(500));
      System.out.print("Read value ");
      System.out.println(rw.r());
    }
   } catch (InterruptedException e) {
     System.out.println("Interrupted");
   }
  }
}


class RWstarveW {
  public static void main(String[] args) {
	final int N = 10;
    RWreg rw = new RWreg();
    Reader r = new Reader(rw);
    new Thread(r).start();
    Writer w = new Writer(rw);
    new Thread(w).start();
  }
}


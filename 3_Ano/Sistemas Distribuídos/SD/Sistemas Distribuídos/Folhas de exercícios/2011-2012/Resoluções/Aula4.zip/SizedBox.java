import java.util.Random;

class Box {
  final int N;
  int stuff = 0;

  public Box(int n) { this.N = n; }

  public synchronized void put() throws InterruptedException {
    while (stuff == N)
       wait();
    stuff++;
    System.out.println("Size inc to "+stuff);
    notifyAll();
  }

  public synchronized void get() throws InterruptedException {
    while (stuff == 0)
       wait();
    stuff--;
    System.out.println("Size dec to "+stuff);
    notifyAll();
  }
}

class Putter implements Runnable {
  Box b;
  public Putter(Box b) {
    this.b = b;
  }
  public void run() {
	Random rand = new Random();
	int i = 0;
    try {
    while(true) { 
      i++;
      System.out.print("Puting ");
      System.out.println(i);
      Thread.sleep(rand.nextInt(500));
      b.put();
    }
   } catch (InterruptedException e) {
     System.out.println("Interrupted");
   }
  }
}

class Getter implements Runnable {
  Box b;
  public Getter(Box b) {
    this.b = b;
  }
  public void run() {
	Random rand = new Random();
	int i = 0;
    try {
    while(true) { 
      i++;
      System.out.print("Getting ");
      System.out.println(i);
      Thread.sleep(rand.nextInt(500));
      b.get();
    }
   } catch (InterruptedException e) {
     System.out.println("Interrupted");
   }
  }
}


class SizedBox {
  public static void main(String[] args) {
	final int N = 10;
    Box b = new Box(N);
    Putter p = new Putter(b);
    new Thread(p).start();
    Getter g = new Getter(b);
    new Thread(g).start();
  }
}


import java.util.Random;
import java.util.concurrent.locks.ReentrantLock;
import java.util.concurrent.locks.Condition;

class Box {
  final int N;
  int stuff = 0;
  final ReentrantLock l = new ReentrantLock();
  final Condition full = l.newCondition();
  final Condition empty = l.newCondition();

  public Box(int n) { this.N = n; }

  public void put() throws InterruptedException {
    l.lock();
    while (stuff == N)
       full.await();
    stuff++;
    System.out.println("Size inc to "+stuff);
    empty.signalAll();
    l.unlock();
  }

  public void get() throws InterruptedException {
    l.lock();
    while (stuff == 0)
       empty.await();
    stuff--;
    System.out.println("Size dec to "+stuff);
    full.signalAll();
    l.unlock();
  }
}

class Putter implements Runnable {
  Box b;
  public Putter(Box b) {
    this.b = b;
  }
  public void run() {
	Random rand = new Random();
	int i = 0;
    try {
    while(true) { 
      i++;
      System.out.print("Puting ");
      System.out.println(i);
      Thread.sleep(rand.nextInt(500));
      b.put();
    }
   } catch (InterruptedException e) {
     System.out.println("Interrupted");
   }
  }
}

class Getter implements Runnable {
  Box b;
  public Getter(Box b) {
    this.b = b;
  }
  public void run() {
	Random rand = new Random();
	int i = 0;
    try {
    while(true) { 
      i++;
      System.out.print("Getting ");
      System.out.println(i);
      Thread.sleep(rand.nextInt(500));
      b.get();
    }
   } catch (InterruptedException e) {
     System.out.println("Interrupted");
   }
  }
}


class ExplicitSizedBox {
  public static void main(String[] args) {
	final int N = 10;
    Box b = new Box(N);
    Putter p = new Putter(b);
    new Thread(p).start();
    Getter g = new Getter(b);
    new Thread(g).start();
  }
}


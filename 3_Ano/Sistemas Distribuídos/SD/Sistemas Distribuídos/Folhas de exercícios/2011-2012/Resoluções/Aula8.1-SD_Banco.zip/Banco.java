package cap5.exercicio5;

import java.util.Arrays;

public class Banco {
	private Conta[] contas;
	
	public Banco(int nContas){
		contas=new Conta[nContas];
		for(int i=0;i<nContas;i++){
			this.contas[i]=new Conta(0);
		}
	}
	public double getSaldoTotal(int i){
		double total;
		if (i<this.contas.length)
		{
			synchronized (this.contas[i]) {
				total=getSaldoTotal(i+1);
				total+=this.contas[i].getSaldo();				
			}	
		}
		else 
			total=0;
		return total;
	}
	
	public double getSaldo(int conta){
		System.out.println("getSaldo: "+conta);
		return contas[conta].getSaldo();
	}
	public void credita(int conta,double valor){
		this.contas[conta].credita(valor);
		
	}
	public void debita(int conta,double valor){
		this.contas[conta].debita(valor);
	}
	public void transfere(int contaOrigem,int contaDestino,double valor){		
		//Este codigo esta incorrecto porque pode dar origem a um deadlock se 2 threads concorrentes fizerem a mesma opera��o em sentido inverso.
		/*Conta contaOr=this.contas[contaOrigem];
		Conta contaDest=this.contas[contaDestino];
		synchronized (contaOr) {
			synchronized (contaDest) {
					contaOr.debita(valor);
					contaDest.credita(valor);				
			}
		}*/
		int min=Math.min(contaOrigem, contaDestino);
		int max=Math.max(contaOrigem, contaDestino);
		Conta minConta=this.contas[min];
		Conta maxConta=this.contas[max];
		synchronized (minConta) {
			synchronized (maxConta) {
				if (min==contaOrigem)
				{
					minConta.debita(valor);
					maxConta.credita(valor);
				}
				else
				{
					maxConta.debita(valor);
					minConta.credita(valor);
				}
			}
		}
	}
	
	public static void main(String[] args){
		
	}
}

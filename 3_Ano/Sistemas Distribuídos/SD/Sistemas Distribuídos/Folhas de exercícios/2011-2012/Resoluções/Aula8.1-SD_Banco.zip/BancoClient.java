package cap5.exercicio5;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.net.UnknownHostException;

public class BancoClient {
	final static int GET_SALDO = 1;
	final static int GET_SALDO_TOTAL = 2;
	final static int CREDITO = 3;
	final static int DEBITO = 4;
	final static int TRANSFERE = 5;

	final static int OK = 6;
	final static int KO = 7;
	
	private int port;
	private String remotehost;
	private Socket socket;
	private ObjectOutputStream oos;
	private ObjectInputStream ois;
	
	public BancoClient(String remotehost,int port) throws UnknownHostException, IOException{
		this.port = port;
		this.remotehost = remotehost;
		
		socket = new Socket(remotehost,port);
		oos = new ObjectOutputStream(socket.getOutputStream());
		ois = new ObjectInputStream(socket.getInputStream());
	}
	public double getSaldo(int conta) {
		double saldo = 0;
		try {
			oos.writeInt(GET_SALDO);
			oos.writeInt(conta);
			oos.flush();
			saldo = ois.readDouble();
		} catch (IOException e) {
			e.printStackTrace();
		}
		return saldo;
	}
	public double getSaldoTotal() {
		double saldoTotal = 0;
		try {
			oos.writeInt(GET_SALDO_TOTAL);
			oos.flush();
			saldoTotal = ois.readDouble();
		} catch (IOException e) {
			e.printStackTrace();
		}
		return saldoTotal;
	}
	public void credito(int conta, double montante) {
		try {
			oos.writeInt(CREDITO);
			oos.writeInt(conta);
			oos.writeDouble(montante);
			oos.flush();
			int status = ois.readInt(); //FIXME: we should eventually check this ...
			if (status == OK){
				System.out.println("Operacao Credito conlcuida com sucesso");
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	public void debito(int conta, double montante) {
		try {
			oos.writeInt(DEBITO);
			oos.writeInt(conta);
			oos.writeDouble(montante);
			oos.flush();
			int status = ois.readInt(); //FIXME: we should eventually check this ...
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	public void transfere(int contaOrigem, int contaDestino, double montante) {
		try {
			oos.writeInt(TRANSFERE);
			oos.writeInt(contaOrigem);
			oos.writeInt(contaDestino);
			oos.writeDouble(montante);
			oos.flush();
			int status = ois.readInt(); //FIXME: we should eventually check this ...
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	public void disconnect() throws IOException{
		socket.shutdownInput(); //acabou o input de mais n�meros
		socket.shutdownOutput();
		socket.close();
	}
	public static void main(String[] args) {
		try {
			BancoClient client = new BancoClient("localhost",2000);
			
			System.out.println("Saldo total: "+client.getSaldoTotal());
			client.credito(1, 15);
			System.out.println("Saldo total: "+client.getSaldoTotal());
			System.out.println(client.getSaldo(9));
			client.credito(9, 100);
			System.out.println(client.getSaldo(9));
			client.disconnect();
			
		} catch (UnknownHostException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}

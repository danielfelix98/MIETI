package cap5.exercicio5;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.OutputStreamWriter;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;

public class BancoServer {
	private int port;
	private Banco banco;
	
	final static int GET_NUMERO_CONTAS = 0;
	final static int GET_SALDO = 1;
	final static int GET_SALDO_TOTAL = 2;
	final static int CREDITO = 3;
	final static int DEBITO = 4;
	final static int TRANSFERE = 5;
	final static int OK = 6;
	final static int KO = 7;

	private ObjectInputStream ois;
	private ObjectOutputStream oos;
	
	public static void main(String[] args) {
		BancoServer server = new BancoServer(2000);
		server.start();
	}
	public BancoServer(int port){
		this.port = port;
		this.banco = new Banco(10);
	}
	public void start() {
		try {
			ServerSocket sSock = new ServerSocket(port);
			while (true) {
				System.out.println("Waiting for clients.");
				Socket sock = sSock.accept();
				System.out.println("Client accepted! Client remot port:"+sock.getPort());
				ois= new ObjectInputStream(sock.getInputStream());
				oos = new ObjectOutputStream(sock.getOutputStream());			
				boolean go = true;
				int op;				
				while (go) {
					try{
					 op = ois.readInt();
					 System.out.println("Received operation with number="+op);
					 parseOp(op);
					}catch (java.io.EOFException e){
						go = false;
					}
				}
				System.out.println("Client disconnected...");
				sock.shutdownInput(); //acabou o input de mais n�meros
				sock.shutdownOutput();
				sock.close();
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	public void parseOp(Integer op) throws IOException{
		switch(op) {
		case GET_SALDO:
			int nConta = ois.readInt();
			double saldo = banco.getSaldo(nConta);
			System.out.println("Cliente: " + nConta + " GET SALDO: "+saldo);
			oos.writeDouble(saldo);
			oos.flush();
			break;
		case GET_SALDO_TOTAL:
			double saldoTotal = banco.getSaldoTotal(0);
			System.out.println("GET_SALDO_TOTAL");
			oos.writeDouble(saldoTotal);
			oos.flush();
			break;
		case CREDITO:
			int contaOrigem = ois.readInt();
			double montante = ois.readDouble();
			System.out.println("Cliente: " + contaOrigem + " CREDITO Montante:" + montante);
			banco.credita(contaOrigem, montante);
			oos.writeInt(OK);
			oos.flush();
			break;
		case DEBITO:
			contaOrigem = ois.readInt();
			montante = ois.readDouble();
			System.out.println("Cliente: " + contaOrigem + " DEBITO Montante:" + montante);
			banco.debita(contaOrigem, montante);
			oos.writeInt(OK);
			oos.flush();
			break;
		case TRANSFERE:
			contaOrigem = ois.readInt();
			int contaDestino = ois.readInt();
			montante = ois.readDouble();
			System.out.println("Cliente: " + contaOrigem + " TRANSFERE Montante:" + montante + " para: " + contaDestino);
			banco.transfere(contaOrigem, contaDestino, montante);
			oos.writeInt(OK);
			oos.flush();
			break;
		default:
				System.out.println("ERRO!");
				oos.writeInt(KO);
				oos.flush();
		}
	}
}

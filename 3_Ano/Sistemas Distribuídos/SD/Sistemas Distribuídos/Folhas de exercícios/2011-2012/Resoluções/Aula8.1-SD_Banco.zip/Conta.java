package cap5.exercicio5;

public class Conta {
	private double saldo;
	
	public Conta(double saldo)
	{
		this.saldo=saldo;
	}
	
	public synchronized void credita(double valor) {
		System.out.println("Conta:"+this);
		this.saldo+=valor;
		this.notifyAll();
	}

	public synchronized void debita(double valor) {
		while(this.saldo<valor)
			try {
				System.out.println(" espera que o meu saldo:"+this.saldo+" seja maior ou igual do que "+valor);
				this.wait();
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		this.saldo-=valor;
	}

	public synchronized double getSaldo() {
		return this.saldo;
	}
}

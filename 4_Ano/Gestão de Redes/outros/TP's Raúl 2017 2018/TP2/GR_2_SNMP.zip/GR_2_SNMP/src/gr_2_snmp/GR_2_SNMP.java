
package gr_2_snmp;

import java.io.IOException;
import java.awt.Frame;
import java.io.IOException;
import javax.swing.JOptionPane;
import org.snmp4j.smi.OID;

/**
 *
 * @author raul
 */
public class GR_2_SNMP {

private double physicalsize;
private double physicalused;
private double virtualsize;
private double virtualused;
private double homesize;
private double homeused;
private double usersize;
private double userused;
private double shmsize;
private double shmused;

    
    public GR_2_SNMP() {
	this.physicalsize = 0;
	this.physicalused = 0;
	this.virtualsize = 0;
	this.virtualused = 0;
	this.homesize = 0;
	this.homeused = 0;
	this.usersize = 0;
	this.userused = 0;
	this.shmsize = 0;
	this.shmused = 0;

    }

    public GR_2_SNMP(String physicalsize, String physicalused, String virtualsize, String virtualused, String homesize, String homeused, String usersize, String userused, String shmsize, String shmused) {
	this.physicalsize  = Double.parseDouble(physicalsize);
	this.physicalused  = Double.parseDouble(physicalused);
	this.virtualsize  = Double.parseDouble(virtualsize);
	this.virtualused  = Double.parseDouble(virtualused);
	this.homesize  = Double.parseDouble(homesize);
	this.homeused  = Double.parseDouble(homeused);
	this.usersize  = Double.parseDouble(usersize);
	this.userused  = Double.parseDouble(userused);
	this.shmsize  = Double.parseDouble(shmsize);
	this.shmused  = Double.parseDouble(shmused);

    }

    public GR_2_SNMP(double physicalsize, double physicalused, double virtualsize, double virtualused, double homesize, double homeused, double usersize, double userused, double shmsize, double shmused) {

	this.physicalsize = physicalsize;
	this.physicalused = physicalused;
	this.virtualsize = virtualsize;
	this.virtualused = virtualused;
	this.homesize = homesize;
	this.homeused = homeused;
	this.usersize = usersize;
	this.userused = userused;
	this.shmsize = shmsize;
	this.shmused = shmused;
    }

/////////////////////////////////////////////////////////////////////
   public double getPhysicalsize() {
        return this.physicalsize;
    }

    public void setPhysicalsize(double physicalsize) {
        this.physicalsize = physicalsize;
    }

    public void setPhysicalsize(String physicalsize) {
        this.physicalsize = Double.parseDouble(physicalsize);
    }
////////////////////////////////////////////////////////
    public double getPhysicalused() {
        return this.physicalused;
    }

    public void setPhysicalused(double physicalused) {
        this.physicalused = physicalused;
    }

    public void setPhysicalused(String physicalused) {
        this.physicalused = Double.parseDouble(physicalused);
    }
//////////////////////////////////////////////////////////////
    public double getVirtualsize() {
        return this.virtualsize;
    }

    public void setVirtualsize(double virtualsize) {
        this.virtualsize = virtualsize;
    }

    public void setVirtualsize(String virtualsize) {
        this.virtualsize = Double.parseDouble(virtualsize);
    }
//////////////////////////////////////////////////////////
    public double getVirtualused() {
        return this.virtualused;
    }

    public void setVirtualused(double virtualused) {
        this.virtualused = virtualused;
    }

    public void setVirtualused(String virtualused) {
        this.virtualused = Double.parseDouble(virtualused);
    }
/////////////////////////////////////////////
    public double getHomesize() {
        return this.homesize;
    }

    public void setHomesize(double homesize) {
        this.homesize = homesize;
    }

    public void setHomesize(String homesize) {
        this.homesize = Double.parseDouble(homesize);
    }
/////////////////////////////////////////////////
    public double getHomeused() {
        return this.homeused;
    }

    public void setHomeused(double homeused) {
        this.homeused = homeused;
    }

    public void setHomeused(String homeused) {
        this.homeused = Double.parseDouble(homeused);
    }

///////////////////////////////////////////////
    public double getUsersize() {
        return this.usersize;
    }

    public void setUsersize(double usersize) {
        this.usersize = usersize;
    }

    public void setUsersize(String usersize) {
        this.usersize = Double.parseDouble(usersize);
    }
//////////////////////////////////////////////////
    public double getUserused() {
        return this.userused;
    }

    public void setUserused(double userused) {
        this.userused = userused;
    }

    public void setUserused(String userused) {
        this.userused = Double.parseDouble(userused);
    }
//////////////////////////////////////////////
    public double getShmsize() {
        return this.shmsize;
    }

    public void setShmsize(double shmsize) {
        this.shmsize= shmsize;
    }

    public void setShmsize(String shmsize) {
        this.shmsize = Double.parseDouble(shmsize);
    }
/////////////////////////////////////////////////
    public double getShmused() {
        return this.shmused;
    }

    public void setShmused(double shmused) {
        this.shmused= shmused;
    }

    public void setShmused(String shmused) {
        this.shmused = Double.parseDouble(shmused);
    }


    public void loadValues(String IP, String port) throws IOException {
	String IPphysicalsize = null;
	String IPphysicalused = null;
	String IPvirtualsize = null;
	String IPvirtualused = null;
	String IPhomesize = null;
	String IPhomeused = null;
	String IPusersize = null;
	String IPuserused = null;
	String IPshmsize = null;
	String IPshmused = null;

        String host = IP.concat("/").concat(port);
        SNMPManager client = new SNMPManager(host);
        client.start();

	IPphysicalsize = client.getAsString(new OID("1.3.6.1.2.1.25.2.3.1.5.1"));
	IPphysicalused = client.getAsString(new OID("1.3.6.1.2.1.25.2.3.1.6.1"));
	IPvirtualsize = client.getAsString(new OID("1.3.6.1.2.1.25.2.3.1.5.3"));
	IPvirtualused = client.getAsString(new OID("1.3.6.1.2.1.25.2.3.1.6.3"));
	IPhomesize = client.getAsString(new OID("1.3.6.1.2.1.25.2.3.1.5.45"));
	IPhomeused = client.getAsString(new OID("1.3.6.1.2.1.25.2.3.1.6.45"));
	IPusersize = client.getAsString(new OID("1.3.6.1.2.1.25.2.3.1.5.43"));
	IPuserused = client.getAsString(new OID("1.3.6.1.2.1.25.2.3.1.6.43"));
	IPshmsize = client.getAsString(new OID("1.3.6.1.2.1.25.2.3.1.5.42"));
	IPshmused = client.getAsString(new OID("1.3.6.1.2.1.25.2.3.1.6.42"));
	
	this.setPhysicalsize(IPphysicalsize);
	this.setPhysicalused(IPphysicalused);
	this.setVirtualsize(IPvirtualsize);
	this.setVirtualused(IPvirtualused);
	this.setHomesize(IPhomesize);
	this.setHomeused(IPhomeused);
	this.setUsersize(IPusersize);
	this.setUserused(IPuserused);
	this.setShmsize(IPshmsize);
	this.setShmused(IPshmused);

    }
}
#include <SimpleSyntax.h>
#include <ObjectSyntax.h>
#include <ObjectName.h>
#include <VarBind.h>
#include <VarBindList.h>
#include <SetRequest-PDU.h>
#include <GetRequest-PDU.h>
#include <PDUs.h>
#include <ANY.h>
#include <Message.h>
#include <OCTET_STRING.h>
#include <stdio.h>
#include <sys/socket.h>
#include <unistd.h>
#include <string.h>
#include <stdlib.h>
#include <math.h>
int convertBinaryToDecimal(long long n);

int main(){

int ee = 0;
uint8_t buffer_final[2048];
size_t buffer_final_size = sizeof(buffer_final);

if(ee==0){

FILE *fp = fopen("/home/raul/Desktop/encode/EncoderResult.txt", "r");
if (fp == NULL)
{
    printf("Error opening file!\n");
    exit(1);
}

char buf[BUFSIZ] = {'\0'}; 

while (fgets(buf,BUFSIZ, fp)!=NULL)
        fputs(buf, stdout);

buffer_final[BUFSIZ]; int h;

for(h=0;h<BUFSIZ;h++)
	buffer_final[h] = buf[h];

printf("Valores no uint8_t: %s",buffer_final);
size_t buffer_final_size = sizeof(buffer_final);

fclose(fp);
}
else{

struct sockaddr_in addr; 
addr.sin_family = AF_INET; //AF_INET: família de endereços a utilizar
addr.sin_port = htons(8080); //161: porta a onde o socket irá estar à escuta 
addr.sin_addr.s_addr = htonl(INADDR_ANY); //INADDR_ANY: IPs a que o socket estará ligado, neste caso todos os da máquina 
int sock = socket(AF_INET, SOCK_DGRAM, 0); //sock: socket  que permite ouvir os pacotes recebidos na porta 9999 
socklen_t udp_socket_size = sizeof(addr); 
bind(sock, (struct sockaddr *)&addr, udp_socket_size); //bind: associa o socket a um endereço IP e porta específicos, indicados na estrutura sockaddr_in 

int recv = recvfrom(sock, buffer_final, buffer_final_size, 0, (struct sockaddr *)&addr, &udp_socket_size); }//Acaba o ELSE


Message_t *message2 = 0; 
asn_dec_rval_t rval = asn_decode(0, ATS_BER, &asn_DEF_Message, (void **)&message2, buffer_final, buffer_final_size); 

PDUs_t* pdu2 = 0; 
asn_dec_rval_t rval2 = asn_decode(0, ATS_BER, &asn_DEF_PDUs, (void **)&pdu2, message2->data.buf, message2->data.size); //Obter data através de message->data

PDUs_t* pdu3 = pdu2;
VarBindList_t var_bindings = pdu3->choice.set_request.variable_bindings; 
int var_list_size = var_bindings.list.count; 
VarBind_t* var_bind = var_bindings.list.array[0]; 

printf("A mensagem: \n);
int i;
for(i=0; i<var_list_size; i++){
var_bind = var_bindings.list.array[i]; 
printf("%s ", var_bind);}


return 0;
}

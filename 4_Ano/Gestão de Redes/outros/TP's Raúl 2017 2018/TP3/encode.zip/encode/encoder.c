#include <SimpleSyntax.h>
#include <ObjectSyntax.h>
#include <ObjectName.h>
#include <VarBind.h>
#include <VarBindList.h>
#include <SetRequest-PDU.h>
#include <GetRequest-PDU.h>
#include <PDUs.h>
#include <ANY.h>
#include <Message.h>
#include <OCTET_STRING.h>
#include <stdio.h>
#include <sys/socket.h>
#include <unistd.h>
#include <string.h>
#include <stdlib.h>
#include <math.h>
long long convertDecimalToBinary(uint8_t n);
    
int main()
{
printf("Insira o comando, no final adicione o valor inteiro, versao de SNMP, requestID\n");
char guarda[2048];
read(0,guarda,sizeof(guarda));
int contador = 0; 
uint8_t buffer[2048];
size_t buffer_size = sizeof(buffer);
uint8_t buffer_final[2048];
size_t buffer_final_size = sizeof(buffer_final);
char *split = strtok(guarda," ");
char* snmp; char* com; char* ip; char* porta; uint8_t* name; int val; int versao; int reqID;
while(split != NULL)
{
	switch(contador){
	case 0: 
		snmp = split; printf("SNMP: %s\n",snmp);
		split=strtok(NULL," :"); contador ++;
		break;
	case 1:
		com = split; printf("Community: %s\n",com);
		split=strtok(NULL," :"); contador ++;
		break;
	case 2:
		ip = split; printf("IP: %s\n",ip);
		split=strtok(NULL," :"); contador ++;
		break;
	case 3:
		porta = split; printf("Porta: %s\n",porta);
		split=strtok(NULL," :"); contador ++;
		break;
	case 4:
		name = split; printf("OID: %s\n",name);
		split=strtok(NULL," :"); contador++;
		break;
	case 5:
		val = split; printf("Valor: %s\n",split);
		split=strtok(NULL," :"); contador++;
		break;
	case 6:
		versao = split; printf("Versao: %s\n",split);
		split=strtok(NULL," :"); contador++;
		break;
	case 7:
		reqID = split; printf("RequestID: %s\n",split);
		split=strtok(NULL," :"); contador++;
		break;
	default:
		split = NULL;
		break;
	}
	
}
//Inteiro e OID
SimpleSyntax_t* simple; 
simple = calloc(1, sizeof(SimpleSyntax_t)); 
simple->present = SimpleSyntax_PR_integer_value; 
simple->choice.integer_value = val; 		//Atribuo o valor inteiro 

ObjectSyntax_t* object_syntax; 
object_syntax = calloc(1, sizeof(ObjectSyntax_t)); 
object_syntax->present = ObjectSyntax_PR_simple; 
object_syntax->choice.simple = *simple; 

size_t name_size = sizeof(name);

ObjectName_t* object_name; 
object_name = calloc(1, sizeof(ObjectName_t)); 
object_name->buf = name;  			//Atribuo o OID
object_name->size = name_size; 

//IP e PORTA
SimpleSyntax_t* simple2; 
simple2 = calloc(1, sizeof(SimpleSyntax_t)); 
simple2->present = SimpleSyntax_PR_integer_value; 
simple2->choice.integer_value = porta; 		//atribuo a porta

ObjectSyntax_t* object_syntax2; 
object_syntax2 = calloc(1, sizeof(ObjectSyntax_t)); 
object_syntax2->present = ObjectSyntax_PR_simple; 
object_syntax2->choice.simple = *simple; 

size_t ip_size = sizeof(ip);
ObjectName_t* object_name2; 
object_name2 = calloc(1, sizeof(ObjectName_t)); 
object_name2->buf = ip;  			//Atribuo o IP
object_name2->size = ip_size;

//versao e snmp
SimpleSyntax_t* simple3; 
simple3 = calloc(1, sizeof(SimpleSyntax_t)); 
simple3->present = SimpleSyntax_PR_integer_value; 
simple3->choice.integer_value = versao; 	//atribuo a porta

ObjectSyntax_t* object_syntax3; 
object_syntax3 = calloc(1, sizeof(ObjectSyntax_t)); 
object_syntax3->present = ObjectSyntax_PR_simple; 
object_syntax3->choice.simple = *simple; 

size_t snmp_size = sizeof(snmp);
ObjectName_t* object_name3; 
object_name3 = calloc(1, sizeof(ObjectName_t)); 
object_name3->buf = snmp;  			//Atribuo o IP
object_name3->size = snmp_size;

//community e requestID
SimpleSyntax_t* simple4; 
simple4 = calloc(1, sizeof(SimpleSyntax_t)); 
simple4->present = SimpleSyntax_PR_integer_value; 
simple4->choice.integer_value = reqID; 	//atribuo a porta

ObjectSyntax_t* object_syntax4; 
object_syntax4 = calloc(1, sizeof(ObjectSyntax_t)); 
object_syntax4->present = ObjectSyntax_PR_simple; 
object_syntax4->choice.simple = *simple; 

size_t com_size = sizeof(com);
ObjectName_t* object_name4; 
object_name4 = calloc(1, sizeof(ObjectName_t)); 
object_name4->buf = com;  			//Atribuo o IP
object_name4->size = com_size;

//Variaveis para lista
VarBind_t* var_bind; 
var_bind = calloc(1, sizeof(VarBind_t)); 
var_bind->name = *object_name; 
var_bind->choice.present = choice_PR_value; 
var_bind->choice.choice.value = *object_syntax; 

VarBind_t* var_bind2; 
var_bind2 = calloc(1, sizeof(VarBind_t)); 
var_bind2->name = *object_name2; 
var_bind2->choice.present = choice_PR_value; 
var_bind2->choice.choice.value = *object_syntax2;

VarBind_t* var_bind3; 
var_bind3 = calloc(1, sizeof(VarBind_t)); 
var_bind3->name = *object_name3; 
var_bind3->choice.present = choice_PR_value; 
var_bind3->choice.choice.value = *object_syntax3;

VarBind_t* var_bind4; 
var_bind4 = calloc(1, sizeof(VarBind_t)); 
var_bind4->name = *object_name4; 
var_bind4->choice.present = choice_PR_value; 
var_bind4->choice.choice.value = *object_syntax4;

VarBindList_t* varlist; 
varlist = calloc(1, sizeof(VarBindList_t)); 
int r = ASN_SEQUENCE_ADD(&varlist->list, var_bind); //Repetir para as outras variaveis que adicionei
int r1 = ASN_SEQUENCE_ADD(&varlist->list, var_bind2);
int r2 = ASN_SEQUENCE_ADD(&varlist->list, var_bind3);
int r3 = ASN_SEQUENCE_ADD(&varlist->list, var_bind4);

if(snmp == "snmpset"){ //SNMPSET
SetRequest_PDU_t* setRequestPDU; 
setRequestPDU = calloc(1, sizeof(GetRequest_PDU_t)); 
setRequestPDU->request_id = reqID; //Request ID
setRequestPDU->error_index = 0; 
setRequestPDU->error_status = 0; 
setRequestPDU->variable_bindings = *varlist; 

PDUs_t *pdu; 
pdu = calloc(1, sizeof(PDUs_t)); 
pdu->present = PDUs_PR_set_request; 
pdu->choice.set_request = *setRequestPDU;

asn_enc_rval_t ret = asn_encode_to_buffer(0, ATS_BER, &asn_DEF_PDUs, pdu, buffer, buffer_size); 

xer_fprint(stdout,&asn_DEF_PDUs,pdu);

//char* com = "public";
ANY_t* data; 
data = calloc(1, sizeof(ANY_t)); 
data->buf = buffer; 
data->size = ret.encoded;

Message_t* message; 
message = calloc(1, sizeof(Message_t)); 
message->version = versao; //versao snmp
message->community.buf = strdup(com);
message->community.size = strlen(com); 
message->data = *data; 


xer_fprint(stdout,&asn_DEF_Message,message); //verificar a estrutura

asn_enc_rval_t ret2 = asn_encode_to_buffer(0, ATS_BER, &asn_DEF_Message, message, buffer_final, buffer_final_size);

}else{//SNMPGET
GetRequest_PDU_t * getRequestPDU;
getRequestPDU = calloc(1, sizeof(GetRequest_PDU_t)); 
getRequestPDU->request_id = reqID; //Request ID
getRequestPDU->error_index = 0; 
getRequestPDU->error_status = 0; 
getRequestPDU->variable_bindings = *varlist; 

PDUs_t *pdu; 
pdu = calloc(1, sizeof(PDUs_t)); 
pdu->present = PDUs_PR_set_request; 
pdu->choice.set_request = *getRequestPDU;

asn_enc_rval_t ret = asn_encode_to_buffer(0, ATS_BER, &asn_DEF_PDUs, pdu, buffer, buffer_size); 

xer_fprint(stdout,&asn_DEF_PDUs,pdu);

//char* com = "public";
ANY_t* data; 
data = calloc(1, sizeof(ANY_t)); 
data->buf = buffer; 
data->size = ret.encoded;

Message_t* message; 
message = calloc(1, sizeof(Message_t)); 
message->version = versao; //versao snmp
message->community.buf = strdup(com);
message->community.size = strlen(com); 
message->data = *data; 

xer_fprint(stdout,&asn_DEF_Message,message); //verificar a estrutura

asn_enc_rval_t ret2 = asn_encode_to_buffer(0, ATS_BER, &asn_DEF_Message, message, buffer_final, buffer_final_size);

}


//FILE
FILE *fp = fopen("EncoderResult.txt", "w");
if (fp == NULL)
{
    printf("Error opening file!\n");
    exit(1);
}
int h; int binary;
for(h = 0; h < buffer_final_size ; h++){
	binary = convertDecimalToBinary(buffer_final[h]);
	fprintf(fp, "%d" , binary);
}

fclose(fp);

//Socket
struct sockaddr_in addr; 
addr.sin_family = AF_INET; //AF_INET: família de endereços a utilizar
addr.sin_port = htons(8080); //161: porta para escrever get,set,get-bulk
addr.sin_addr.s_addr =  inet_addr("127.0.0.1"); //Ip da porta
int sock = socket(AF_INET, SOCK_DGRAM, 0); //sock: socket  que permite ouvir os pacotes recebidos na porta 9999 
socklen_t udp_socket_size = sizeof(addr); 

int sent = sendto(sock, buffer_final, buffer_final_size, 0, (struct sockaddr *)&addr, udp_socket_size);

return 0; 
}

long long convertDecimalToBinary(uint8_t n)
{
    long long binaryNumber = 0;
    int remainder, i = 1, step = 1;

    while (n!=0)
    {
        remainder = n%2;
        //printf("Step %d: %d/2, Remainder = %d, Quotient = %d\n", step++, n, remainder, n/2);
        n /= 2;
        binaryNumber += remainder*i;
        i *= 10;
    }
    return binaryNumber;
}

